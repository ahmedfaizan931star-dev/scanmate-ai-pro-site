# Safe Codespaces upload commands

Use these after you create/open the `scanmate-ai-pro-site` repo in GitHub Codespaces and upload the ZIP.

```bash
unzip -o scanmate-ai-pro-site.zip
find . -maxdepth 1 -type f | sort

git status
git add -A
git commit -m "Add ScanMate AI Pro website and policy pages"
git push origin main
```

Then enable GitHub Pages:

```text
Repository → Settings → Pages → Deploy from a branch → main → /root → Save
```

Wait 1–10 minutes and open:

```text
https://ahmedfaizan931star-dev.github.io/scanmate-ai-pro-site/
```
